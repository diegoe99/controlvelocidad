/*
 * ControlVelocidad_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "ControlVelocidad".
 *
 * Model version              : 1.11
 * Simulink Coder version : 9.6 (R2021b) 14-May-2021
 * C source code generated on : Sun May  7 00:06:31 2023
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_ControlVelocidad_types_h_
#define RTW_HEADER_ControlVelocidad_types_h_

/* Model Code Variants */

/* Forward declaration for rtModel */
typedef struct tag_RTM_ControlVelocidad_T RT_MODEL_ControlVelocidad_T;

#endif                                /* RTW_HEADER_ControlVelocidad_types_h_ */
